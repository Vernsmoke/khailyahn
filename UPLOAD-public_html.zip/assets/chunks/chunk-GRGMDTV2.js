import{c as e}from"./chunk-WOK7RHOK.js";import{b as t}from"./chunk-6DHFEWGX.js";var r=t(e());function n({prefetch:c,...o}){return(0,r.jsx)("a",{...o})}export{n as a};
